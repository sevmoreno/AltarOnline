//
//  User.swift
//  altar
//
//  Created by Juan Moreno on 9/13/19.
//  Copyright © 2019 Juan Moreno. All rights reserved.
//

import UIKit

class User: NSObject {
    
    var userID: String = ""
    var photoUser: String = ""
    var fullName: String = ""
    var churchUser: String = ""
    var email: String = ""

}
