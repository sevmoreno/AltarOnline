//
//  UserHeaderCollectionViewCell.swift
//  altar
//
//  Created by Juan Moreno on 1/3/20.
//  Copyright © 2020 Juan Moreno. All rights reserved.
//

import UIKit

class UserHeaderCollectionViewCell: UICollectionViewCell {
    
}
